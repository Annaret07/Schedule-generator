from pathlib import Path
from deap import tools
from GeneticAlgorithm import GeneticAlgorithm, load_results_from_dat, save_results_to_dat, Config
from Entities import ScheduleConfig, MainData
from ExcelParser import ExcelParser
from ScheduleExporter import ScheduleExporter

def main():
    data_path = Path().resolve() / "data" / "input_constraints.xlsx"
    parser = ExcelParser(data_path)
    parser.setup()

    config = ScheduleConfig(
        daily_hours_limit=8,
        weekly_hours_limit=48,
        daily_difficult_hours_limit=5
    )

    # Genetic Algorithm setup
    algo = GeneticAlgorithm(config=Config(), data=parser.data)

    # Load results from DAT file or run the genetic algorithm
    population_selected = load_results_from_dat()

    if population_selected:
        print("Previous algorithm results found. Do you want to load them and write to excel file? (y/n)")
        answer = ""
        while answer.lower() != "y" and answer.lower() != "n":
            answer = input()
            if answer.lower() == "y":
                algo.population = population_selected
            elif answer.lower() == "n":
                print("Start recalculation")
                population_selected = algo.run()
                save_results_to_dat(population_selected)
    
    if population_selected is None:
        population_selected = algo.run()
        save_results_to_dat(population_selected)

    best_individual = tools.selBest(population_selected, 1)[0]

    # Export the generated schedule
    exporter = ScheduleExporter(best_individual, algo.encoding, parser.data)  
    exporter.export_to_excel()


if __name__ == '__main__':
    main()