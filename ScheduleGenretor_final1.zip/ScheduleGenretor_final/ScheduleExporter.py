from pprint import pprint
import openpyxl
from openpyxl import Workbook
from openpyxl.utils import get_column_letter
from openpyxl.styles import Alignment
from GeneticAlgorithm import Config
from pathlib import Path

class ScheduleExporter:
    def __init__(self, best_individual, encoding, data, file_name=Path().resolve() / "data" / "output_schedule.xlsx"):
        self.best_individual = best_individual
        self.encoding = encoding
        self.file_name = file_name
        self.config = Config()
        self.data = data

    def export_to_excel(self):
        l = list(self.data.groups.values())        

        wb = Workbook()
        ws = wb.active
        ws.title = "Расписание"
        
        # Создание заголовков групп (строка 1)
        ws.cell(row=1, column=1, value="День/Слоты")
        for col in range(self.config.n_groups):
            ws.cell(row=1, column=col + 2, value=f"Группа {l[col].name}")  # Starting from column 2

        # Установка ширины столбцов и форматирования
        for col in range(1, ws.max_column + 1):
            ws.column_dimensions[get_column_letter(col)].width = 20  # Increased width
            
        days_of_week = {
            0: "Понедельник",
            1: "Вторник",
            2: "Среда",
            3: "Четверг",
            4: "Пятница",
            5: "Суббота",
            6: "Воскресенье"
        }

        # Заполнение расписания
        current_row = 2
        for day in range(self.config.n_days):
            day_name = days_of_week[day]
            ws.cell(row=current_row, column=1, value=day_name)
            current_row += 1

            for slot in range(self.config.n_hours):
                ws.cell(row=current_row, column=1, value=f"Слот {slot + 1}")

                for group_idx in range(self.config.n_groups):
                    idx = day * self.config.n_hours + slot + group_idx * self.config.n_days * self.config.n_hours

                    try:
                        triple_idx = self.best_individual[idx]
                        teacher_idx, subject_idx, classroom_idx = self.encoding[triple_idx]
                        if triple_idx == 287:
                            print("287====")
                        # Get actual teacher, subject, and classroom names/numbers
                        teacher_name = list(self.data.teachers.keys())[teacher_idx]
                        teacher_subject = self.data.teachers[teacher_name].subjects_name
                        # Assuming subjects are the same for all groups (modify if needed)
                        #subject_name = list(list(self.data.groups.values())[0].subjects.keys())[subject_idx] # Закомментировал 01.10
                        subject_name = self.data.subjects[subject_idx]
                        classroom_number = self.data.rooms[classroom_idx].number

                        cell_value = f"Учитель: {teacher_name}\n" \
                                                          f"Предмет: {subject_name}\n" \
                                                          f"Аудитория: {classroom_number}"

                     #   f"Предмет учителя: {teacher_subject}\n" \
                     # cell_value = f"Учитель: {teacher_name}\n" \
                     #                 f"Предмет: {subject_name}\n" \
                     #                 f"classroom_idx = {classroom_idx}\n" \
                     #                 f" teach+subj+class= triple_idx = {triple_idx}\n" \
                     #                 f"group_idx = {group_idx}\n" \
                     #                 f"day = {day}\n" \
                     #                 f"slot = {slot}\n" \
                     #                 f"Предмет учителя: {teacher_subject}\n" \
                     #                 f"Аудитория: {classroom_number}"

                        cell = ws.cell(row=current_row, column=group_idx + 2, value=cell_value)
                        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)
                    except IndexError:
                        cell = ws.cell(row=current_row, column=group_idx + 2, value="N/A")
                        cell.alignment = Alignment(horizontal="center", vertical="center", wrap_text=True)

                current_row += 1

            current_row += 1  # Add an empty row between days

        # Автоподбор высоты строк
        for row in ws.iter_rows():
            max_height = 0
            for cell in row:
                if cell.value:
                    lines = cell.value.split('\n')
                    height = len(lines) * 14 
                    if height > max_height:
                        max_height = height
            ws.row_dimensions[cell.row].height = max_height if max_height > 0 else 20  # Minimum height

        # Сохранение файла
        wb.save(self.file_name)
        print(f"Расписание успешно экспортировано в файл {self.file_name}")