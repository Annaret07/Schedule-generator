import pickle
import logging
import random
from itertools import product
# from opcode import name_op
from pathlib import Path
from pprint import pprint
from typing import Dict, List, Tuple

from Entities import MainData
import numpy as np
from tqdm import tqdm
from deap import base, creator, tools
import matplotlib.pyplot as plt
from numpy.random import shuffle, choice

from models import Config

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)


class GeneticAlgorithm:
    def __init__(self,
                 config: Config,
                 data:MainData,
                 population_size=550, #200 кол-во индивидуумов
                 crossover_prob=0.7,  #0.7 Вероятность скрещивания
                 mut_pb=0.3,          #0.2 Вероятность мутации
                 num_generations=100): #50 Кол-во поколений
        self.config = config
        self.population_size = population_size
        self.crossover_prob = crossover_prob
        self.mut_pb = mut_pb
        self.num_generations = num_generations
        self.data = data
        self.min_penalty = 10000000
        self.min_penalty1 = 10000000

        self.toolbox = base.Toolbox()
        self._setup_deap()

    def _setup_deap(self):
        creator.create("FitnessMin", base.Fitness, weights=(-1.0,))
        creator.create("Individual", list, fitness=creator.FitnessMin)

        self.encoding_list = list(self.encoding.keys())

        # Register functions to create individuals and populations
        self.toolbox.register("attr_index", random.choice, self.encoding_list)  # Fixed this line
        # self.toolbox.register("individual", tools.initRepeat, creator.Individual,
        #                       self.toolbox.attr_index, n=48)  # 6 days, 8 hours => 6*8 = 48 slots
        self.toolbox.register("individual", lambda: creator.Individual(self.initialize_agent().flatten()))
        self.toolbox.register("population", tools.initRepeat, list, self.toolbox.individual)

        # Register the evaluation function
        self.toolbox.register("evaluate", self.evaluate_schedule)

        # Register genetic operators
        self.toolbox.register("select", tools.selTournament, tournsize=3) # 3
        self.toolbox.register("mate", tools.cxTwoPoint)
        self.toolbox.register("mutate", tools.mutShuffleIndexes, indpb=0.05)

    @property
    def encoding(self) -> Dict[int, Tuple[int, int, int]]:
        """
        Maps id (int, primary) --> triple (teacher, subject, classroom) represents
        a single slot in the schedule.
        """
        # groups = list(range(self.config.n_groups))
        teachers = list(range(self.config.n_teachers))
        subjects = list(range(self.config.n_subjects))
        classrooms = list(range(self.config.n_classrooms))

        triples1 = list(product(*[teachers, subjects, classrooms]))
#       Сгенерировали словарь Учитель, предмет, комната
#       Удалить запрещенные  сочетания учитель - предмет
        triples = []
        for t1 in triples1:
            #if t1 == (12, 8, 17):
            #    print("12-8-17")
        # Проверим может ли учитель вести предмет
            teacher_name = list(self.data.teachers.keys())[t1[0]]

        # Список предметов, которые ведет учитель
            teacher_subjects1 = self.data.teachers[teacher_name].subjects_name
            # Текущий предмет
            subject_name = self.data.subjects[t1[1]]
            if subject_name in teacher_subjects1:
                triples.append(t1)
                #if teacher_name == 'Белоусова':
                #    print(teacher_name, ' предмет = ',subject_name)

        return dict(zip(range(len(triples)), triples))

    def choose_idx(self, group, day, hour):
       # Выбор кода, включающего: учитель, предмет, классная комната
       # Проверяем на соответствие группе дню и часу.
        triple_idxs = list(self.encoding.keys())
        vv = choice(triple_idxs)

        # teacher_idx, subject_idx, classroom_idx = self.encoding[vv]
        '''
        # Get actual teacher, subject, and classroom names/numbers
        teacher_name = list(self.data.teachers.keys())[teacher_idx]
        teacher_subject = self.data.teachers[teacher_name].subjects_name
        # Assuming subjects are the same for all groups (modify if needed)
        subject_name = list(list(self.data.groups.values())[0].subjects.keys())[subject_idx]
        classroom_number = self.data.rooms[classroom_idx].number
        '''
        return vv

    def initialize_agent(self) -> np.ndarray:
        """Agent is a 6x8 (6 days, 8 hours)  matrix where each element is an index
        of the encoding dictionary
        Вызывается столько раз сколько в популяции индивидумов self.population_size
        Агент генерирует одного идивидума это 480 слотов = 10 Групп x 6 дней x 8 часов
        в каждый слот присваивает код (число) с зашифрованными  учитель x предмет x комната
        """

        agent = np.full((self.config.n_groups, self.config.n_days, self.config.n_hours), -1)
        triple_idxs = list(self.encoding.keys())

        for group in range(self.config.n_groups):
            available_slots = [(day, hour) for day in range(self.config.n_days)
                               for hour in range(self.config.n_hours)]
            # Сгененировали слоты по часу на 6 дней по 8 часов
            # И теперь перемешали слоты, зачем-то
            #shuffle(available_slots)

            # teacher, subject, classroom = self.encoding[triple_idx]
            for day, hour in available_slots:
                #vv = choice(triple_idxs)  # Случайный выбор предмет+учитель+комната для слота
                vv = self.choose_idx(group, day, hour)
                teacher, subject, classroom = self.encoding[vv]
                agent[group, day, hour] = vv

        return agent

#   Функция была закомментирована
#    def get_valid_triples(self, agent: np.ndarray, day: int, hour: int) -> list:
    #     """
    #     Get a list of valid (subject, teacher, classroom) triples that can be placed
    #     in the given (day, hour) slot without violating constraints.
    #     """
#        print("Getting valid triples...")
#        valid_triples = []
#        for idx, (teacher, subject, classroom) in self.encoding.items():
#            if not self.conflicts(agent, day, hour, teacher, classroom):
#                print(f"Valid tiple: {idx}")
#                valid_triples.append(idx)
#            else:
#                print(f"Invalid tiple: {idx}")
#
#        return valid_triples

    # def conflicts(self, agent: np.ndarray, day: int, hour: int, teacher: int, classroom: int) -> bool:
    #     """
    #     Check if placing a (teacher, classroom) at (day, hour) conflicts with the current agent's state.
    #     """
    #     # print("Checking for conflicts...")
    #
    #     for h in range(self.config.n_hours):
    #         if agent[day, h] != -1:  # Check only if the slot is filled
    #             existing_teacher, _, existing_classroom = self.encoding[agent[day, h]]
    #             if existing_teacher == teacher or existing_classroom == classroom:
    #                 return True
    #
    #     return False

    def evaluate_schedule(self, individual):
        """
        Evaluate the fitness of an individual (schedule).
        The function returns a penalty score based on how many constraints are violated.
        """
        penalty = 0

        teacher_slots, classroom_slots = {}, {}
        student_schedule = {day: [] for day in range(self.config.n_days)}

                            
        for idx, triple_idx in enumerate(individual):

            # day = idx % self.config.n_days  # Убрал 07.09
            day = ( idx // self.config.n_hours ) % self.config.n_days # Добавил 07.09
            hour = idx % self.config.n_hours
            # Номер группы
            group_idx = idx // (self.config.n_hours * self.config.n_days) # Добавил 07.09

            teacher, subject, classroom = self.encoding[triple_idx]

            student_schedule[day].append(hour)
            # Проверим может ли учитель вести предмет
            teacher_name = list(self.data.teachers.keys())[teacher]
            # Список предметов, которые ведет учитель
            teacher_subjects = self.data.teachers[teacher_name].subjects_name
            # Имя предмета в текущей особи.
            subject_name = list(list(self.data.groups.values())[0].subjects.keys())[subject]
            if not subject_name in teacher_subjects:
                penalty += 5  # Штраф при несоответствии предмета учителю

            # Check if teacher is already teaching at this time
            if (day, hour) in teacher_slots.get(teacher, []):
                penalty += 5
            else:
                teacher_slots.setdefault(teacher, []).append((day, hour))

            # Check if classroom is already occupied at this time
            if (day, hour) in classroom_slots.get(classroom, []):
                penalty += 500
            else:
                classroom_slots.setdefault(classroom, []).append((day, hour))
                
        #print(list(list(self.data.groups.values())[0].subjects.values())[0].time_constraints)
        #print(list(list(self.data.groups.values())[0].subjects.values())[0].day_constraints)        

        for day, hours in student_schedule.items():
            if len(hours) > 1:
                hours.sort()
                for i in range(1, len(hours)):
                    if hours[i] != hours[i - 1] + 1:
                        penalty += 5  # Penalty for each gap in the schedule
                        
    
        logger.debug(f"Evaluated individual with penalty: {penalty}")
        if penalty == 0:
            print('========== УРА')
        if penalty < self.min_penalty:
            self.min_penalty = penalty


        return penalty,
    #
    def generation_evolutionary_loop(self, population: List[List[int]]
                                     ) -> np.ndarray[np.ndarray[np.int8]]:
        offspring = self.toolbox.select(population, len(population))
        offspring = list(map(self.toolbox.clone, offspring)) # Создаем копию / клон

        # Apply crossover and mutation
        for child1, child2 in zip(offspring[::2], offspring[1::2]):
            if random.random() < self.crossover_prob: # Вероятность скрещивания
                self.toolbox.mate(child1, child2)
                del child1.fitness.values  # Это ключевой момент
                del child2.fitness.values  # Это ключевой момент

        for mutant in offspring:
            if random.random() < self.mut_pb: # Проверяем необходимость мутации
                self.toolbox.mutate(mutant)
                del mutant.fitness.values  # Это ключевой момент

        # Evaluate the individuals with an invalid fitness
        invalid_ind = [ind for ind in offspring if not ind.fitness.valid] # Убрал 07.09.24
        #invalid_ind = [ind for ind in offspring if ind.fitness.values[0]<1000] # Добавил 07.09.24
        fitnesses = map(self.toolbox.evaluate, invalid_ind)
        for ind, fit in zip(invalid_ind, fitnesses):
            ind.fitness.values = fit

        # Replace the old population with the new one
        # Вот тут портится population все индивиды становятся одинаковыми
        population[:] = offspring

        # getting stats
        fits = [ind.fitness.values[0] for ind in population]

        length = len(population)
        mean = sum(fits) / length
        sum2 = sum(x * x for x in fits)
        std = abs(sum2 / length - mean ** 2) ** 0.5

        logger.info(f"Min: {min(fits)}")
        logger.info(f"Max: {max(fits)}")
        logger.info(f"Avg: {mean}")
        logger.info(f"Std: {std}")

        return population

    def run(self):
        next_generation = self.toolbox.population(n=self.population_size)
        fitnesses = map(self.toolbox.evaluate, next_generation)

        for ind, fit in zip(next_generation, fitnesses):
            ind.fitness.values = fit #// Это рассчитанный пенальти

            if fit[0] < self.min_penalty1:
                self.min_penalty1 = fit[0]
                print("===MIN===", self.min_penalty1)

        print(type(next_generation))

        for _ in tqdm(range(self.num_generations)):
            next_generation = self.generation_evolutionary_loop(next_generation)

        return next_generation
    
def save_results_to_dat(population, filename="results.dat"):
    with open(filename, 'wb') as f:
        pickle.dump(population, f)
    print(f"Results saved to {filename}")

def load_results_from_dat(filename="results.dat"):
    try:
        with open(filename, 'rb') as f:
            population = pickle.load(f)
        print(f"Results loaded from {filename}")
        return population
    except FileNotFoundError:
        print(f"File {filename} not found. Running genetic algorithm...")
        return None   


if __name__ == "__main__":
    data1 = MainData()
    algo = GeneticAlgorithm(config=Config(), data=data1)
    population_selected = algo.run()
    pprint(population_selected)
